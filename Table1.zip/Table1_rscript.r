######################################################################
# R script for calculating values in Table 1 in:
# 
# Elbers JP, Taylor SS (in review) GO2TR: a gene ontology-based
# workflow to generate target regions for target enrichment
# experiments. Methods in Ecology and Evolution.
#
# Jean P. Elbers
# jean.elbers@gmail.com
# last modified: 19 Mar 2015
######################################################################

#set cwd to where ever you have your GO2TR folder
setwd("/GO2TR")

# import tab-delimited results from bedtools intersect
# to create the following data.frames
# Note:
# ENSEMBL indicates what GO2TR regions overlap ENSEMBL regions
#  in other words ENSEMBL is reference and GO2TR is the query
# GO2TR   indicates what ENSEMBL regions overlap GO2TR regions
#  in other words GO2TR is reference and ENSEMBL is the query
# 
# Rows are genomic interval present in the reference
# Columns (n=13) represent the following:
#   columns 1-6  = chrom,start,end,name,score,strand of the reference
#   columns 7-12 = chrom,start,end,name,score,strand of the query
#   column 13    = overlap or how much the query interval
#                  overlaps the reference interval
ENSEMBL <-read.delim("intersect-f99-r-s-wao.ENS_vs_GO2.bed", header=F)
GO2TR <-read.delim("intersect-f99-r-s-wao.GO2_vs_ENS.bed", header=F)

# need to add 3 new columns:
#   column 14 = length = length of reference interval = col3 - col2 = col3-col2
#   column 15 = non_overlap = if overlap is 0: non_overlap is length, else non_overlap is 0 
#             = if col13 is 0: col15=col14, else col15=0
#   column 16 = flanking = if overlap is 0: flanking is 0, else flanking is length - overlap
#             = if col13 is 0: col16=0, else col16=col14-col13
ENSEMBL$length <- ENSEMBL$V3-ENSEMBL$V2
ENSEMBL$non_overlap <- ifelse(ENSEMBL$V13==0, ENSEMBL$length, 0)
ENSEMBL$flanking <- ifelse(ENSEMBL$V13==0, 0, ENSEMBL$length-ENSEMBL$V13)
GO2TR$length <- GO2TR$V3-GO2TR$V2
GO2TR$non_overlap <- ifelse(GO2TR$V13==0, GO2TR$length, 0)
GO2TR$flanking <-ifelse(GO2TR$V13==0, 0, GO2TR$length-GO2TR$V13)

# calculates the total number intervals for each target region
ENSEMBL_intervals <- nrow(ENSEMBL)
GO2TR_intervals <- nrow(GO2TR)
total_intervals <- c(ENSEMBL_intervals, GO2TR_intervals)

# calculates the total number of bases for each target region
ENSEMBL_bases <- sum(ENSEMBL$length)
GO2TR_bases <- sum(GO2TR$length)
total_bases <- c(ENSEMBL_bases, GO2TR_bases)

# calculates the number of unique intervals for each target region
ENSEMBL_unique_intervals <- nrow(ENSEMBL[ENSEMBL$non_overlap > 0, ])
GO2TR_unique_intervals <- nrow(GO2TR[GO2TR$non_overlap > 0, ])
unique_intervals <- c(ENSEMBL_unique_intervals, GO2TR_unique_intervals)

# calculates the number of unique bases for each target region
ENSEMBL_unique_bases <- sum(ENSEMBL$non_overlap)
GO2TR_unique_bases <- sum(GO2TR$non_overlap)
unique_bases <- c(ENSEMBL_unique_bases, GO2TR_unique_bases)

# calculates the number of flanking intervals for each target region
ENSEMBL_flanking_intervals <- nrow(ENSEMBL[ENSEMBL$flanking > 0, ])
GO2TR_flanking_intervals <- nrow(GO2TR[GO2TR$flanking > 0, ])
flanking_intervals <- c(ENSEMBL_flanking_intervals, GO2TR_flanking_intervals)

# calculates the number of flanking bases for each target region
ENSEMBL_flanking_bases <- sum(ENSEMBL$flanking)
GO2TR_flanking_bases <- sum(GO2TR$flanking)
flanking_bases <- c(ENSEMBL_flanking_bases, GO2TR_flanking_bases)

# calculates the number of shared intervals for each target region
ENSEMBL_shared_intervals <- (ENSEMBL_intervals-ENSEMBL_unique_intervals-ENSEMBL_flanking_intervals)
GO2TR_shared_intervals <- (GO2TR_intervals-GO2TR_unique_intervals-GO2TR_flanking_intervals)
shared_intervals <- c(ENSEMBL_shared_intervals, GO2TR_shared_intervals)

# calculates the number of shared bases for each target region
ENSEMBL_shared_bases <- (ENSEMBL_bases-ENSEMBL_unique_bases-ENSEMBL_flanking_bases)
GO2TR_shared_bases <- (GO2TR_bases-GO2TR_unique_bases-GO2TR_flanking_bases)
shared_bases <- c(ENSEMBL_shared_bases, GO2TR_shared_bases)

# creates vector target_region
target_region <- c("ENSEMBL", "GO2TR")

total <- data.frame("target_region"=target_region, "intervals"=total_intervals, "bases"=total_bases)
shared <- data.frame("target_region"=target_region, "intervals"=shared_intervals, "bases"=shared_bases)
flanking <- data.frame("target_region"=target_region, "intervals"=flanking_intervals, "bases"=flanking_bases)
unique <- data.frame("target_region"=target_region, "intervals"=unique_intervals, "bases"=unique_bases)
total
shared
flanking
unique
# > total
# target_region intervals   bases
# 1       ENSEMBL      3721  878212
# 2         GO2TR      4790 1218559
# > shared
# target_region intervals  bases
# 1       ENSEMBL      1365 206049
# 2         GO2TR      1372 206049
# > flanking
# target_region intervals bases
# 1       ENSEMBL        12    36
# 2         GO2TR         5    15
# > unique
# target_region intervals   bases
# 1       ENSEMBL      2344  672127
# 2         GO2TR      3413 1012495