#!/usr/bin/python

Usage = """
######################################################################
#
# Python 2.7.3 script for getting blast results for Figure 2 in:
# 
# Elbers JP, Taylor SS (in review) GO2TR: a gene ontology-based
# workflow to generate target regions for target enrichment
# experiments. Molecular Ecology Resources.
#
# Jean P. Elbers
# jean.elbers@gmail.com
# last modified: 1 Dec 2014
######################################################################
Program Steps
-------------
This program helps deal with the fact that not all Blast/BLAT queries
are present in the program's output, and without an output, it is difficult
to compare Blast queries on different databases because of missing rows.
As long as the Blast results are in the same format as the queries,
then this program will append the missing rows to the input file as a new
file called filename.out The new outputs can be compared in Excel or using
the supplied Figure2_rscript.r.



(1)Accepts modified blast result file(s) in the format:
Query id	Subject id
Query id	Subject id

Example:
NW_004848299:1099496-1099616:-	NW_005851312:18285-18166:2.0e-51:200.0
NW_004848299:1099542-1099662:-	NW_005851312:18331-18213:1.7e-50:197.0

and converts the input into a dictionary with Query id as the key and
Subject id as the associated value



(2)Parses a list of Blast queries (e.g., stringent-baits.txt)
in the same format as the Blast result:
Query
Query

Example:
NW_004848299:1099496-1099616:-
NW_004848299:1099496-1099616:-

and stores them in a list.



(3)If a Blast query is found within the Blast results dictionary, then
the dictionary entry is outputted (i.e., key and value), else the Blast
query is outputted by itself



Usage:
	To run, navigate to the directory containing blast results
	and blast queries, place this script and stringent-baits.txt in
	the directory, and type:
	
	python getAllBlastQueries.py NameOfInputBlastResultFile.txt
	
		ex: python getAllBlastQueries.py bait_matches_2col_unique_*.txt
		
	The output will be NameOfInputBlastResultFile.txt.out
	which will appear in the same folder."""
	
import sys

if len(sys.argv)<2:
	print Usage	
else:
	FileList= sys.argv[1:]
	
	for InFileName in FileList:
		baits = []
		matches = []
		matchdict = {}
		Infile1 = open(InFileName, 'r')
		for line in Infile1:
			matches.append(line.strip('\n').strip('\r').split('\t'))
		Infile1.close()
		
		# import collections module to acces defaultdict	
		from collections import defaultdict
	
		# The defaultdict option allows for the keys and values to be lists
		matchdict = defaultdict(list)
		for item0, item1 in matches:
			matchdict[item0].append(item1)
		
		with open('stringent-baits.txt', 'r') as file2:
			OutFileName = InFileName + '.out'
			OutFile = open(OutFileName, 'w')
			for line in file2:
				query = line.strip()
				QueryMatch = '%s	%s' % (query,matchdict[query])
				NoMatch = '%s	%s' % (query,"No Match")
				if query in matchdict:
					OutFile.write(QueryMatch)
					OutFile.write('\n')
				else:
					OutFile.write(NoMatch)
					OutFile.write('\n')
			OutFile.close()