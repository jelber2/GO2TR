######################################################################
# R script for calculating and graphing values in Figure 2 in:
# 
# Elbers JP, Taylor SS (in review) GO2TR: a gene ontology-based
# workflow to generate target regions for target enrichment
# experiments. Methods in Ecology and Evolution.
#
# Jean P. Elbers
# jean.elbers@gmail.com
# last modified: 19 Mar 2015
######################################################################

#set cwd to where ever you have you bait results
setwd("C:/Users/jelber2/Dropbox/LSU/Dissertation/Manuscripts/GO2OME/Figure2/")

#load ggplot or get it from CRAN
library("ggplot2")

## Species
# ChrPic = Chrysemys picta bellii, western painted turtle
# GopPol = Gopherus polyphemus, gopher tortoise
# CheMyd = Chelonia mydas, green sea turtle
# PelSin = Pelodiscus sinensis, Chinese softshell
# AllMis = Alligator mississippiensis, American alligator
# PytMol = Python molurus bivittatus, Burmese python
Species <- c("G. polyphemus", "C. mydas",
             "P. sinensis", "A. mississippiensis",
             "P. m. bivittatus")

## Age (Ma) of most recent common ancestor to western painted turtle
# Ma = millions of years ago
# Age[1], Age[2], Age[3] from age estimates of nodes 22, 18, and 2
# respectively from Table 2 in: 
# Near TJ, Meylan PA and Shaffer HB (2005) Assessing Concordance of
# Fossil Calibration Points in Molecular Clock Studies: An Example
# Using Turtles. The American Naturalist 165: 137-146.
# Age[4] and Age[5] from age estimates of nodes 4 and 2 respectively
# from Table 1 in:
# Shedlock AM and Edwards SV (2009) Amniotes (amniota). In:
# S. B. Hedges and S. Kumar, editors. The timetree of life.
# Oxford. pp. 375-379.
# create the vector Age
Age <- c(69.98, 93.68, 174.87, 230.7, 274.9) 

## Percent of Working Baits
# import tab-delimited BLAT search results for each genome
# to create the following data.frames
# start and end are 1-based intervals
# Bait_queries in the form chrm:start-end:strand
# Matches in the format chrm:start-end
# Eval is short of "e-value"
# Bit score is bit score from BLAT
CheMyd <-read.delim("bait_matches_4col_reformat_CheMyd.txt", header=F)
PelSin <-read.delim("bait_matches_4col_reformat_PelSin.txt", header=F)
AllMis <-read.delim("bait_matches_4col_reformat_AllMis.txt", header=F)
PytMol <-read.delim("bait_matches_4col_reformat_PytMol.txt", header=F)
colnames(CheMyd) <- c("Bait_queries","Matches", "Eval", "Bit_score")
colnames(PelSin) <- c("Bait_queries","Matches", "Eval", "Bit_score")
colnames(AllMis) <- c("Bait_queries","Matches", "Eval", "Bit_score")
colnames(PytMol) <- c("Bait_queries","Matches", "Eval", "Bit_score")

# A bait "worked" if it had a bit score > 108 (~10% divergence 
# aka 90% similarity = 120*0.9)
# so only count the rows that have bit scores >= 108
# by filtering the existing data.frames
workbaits_CheMyd <- na.omit(CheMyd[CheMyd$Bit_score >= 108, ])
workbaits_PelSin <- na.omit(PelSin[PelSin$Bit_score >= 108, ])
workbaits_AllMis <- na.omit(AllMis[AllMis$Bit_score >= 108, ])
workbaits_PytMol <- na.omit(PytMol[PytMol$Bit_score >= 108, ])

# Count the number of baits that did not work (i.e., Bit_score < 108 or NA)
num.bad.baits <- as.data.frame(cbind("Baits_queries" = as.character(CheMyd$Bait_queries),
                                     "CheMyd_Matches" = as.character(CheMyd$Matches),
                                     "CheMyd_Bit_score" = as.numeric(CheMyd$Bit_score),
                                     "PelSin_Matches" = as.character(PelSin$Matches),
                                     "PelSin_Bit_score" = as.numeric(PelSin$Bit_score),
                                     "AllMis_Matches" = as.character(AllMis$Matches),
                                     "AllMis_Bit_score" = as.numeric(AllMis$Bit_score),
                                     "PytMol_Matches" = as.character(PytMol$Matches),
                                     "PytMol_Bit_score" = as.numeric(PytMol$Bit_score)))

# convert Matches to characters and Bit_score to numeric
num.bad.baits$Baits_queries <- as.character(num.bad.baits$Baits_queries)
num.bad.baits$CheMyd_Bit_score <- as.numeric(levels(num.bad.baits$CheMyd_Bit_score)[num.bad.baits$CheMyd_Bit_score])
num.bad.baits$PelSin_Bit_score <- as.numeric(levels(num.bad.baits$PelSin_Bit_score)[num.bad.baits$PelSin_Bit_score])
num.bad.baits$AllMis_Bit_score <-  as.numeric(levels(num.bad.baits$AllMis_Bit_score)[num.bad.baits$AllMis_Bit_score])
num.bad.baits$PytMol_Bit_score <- as.numeric(levels(num.bad.baits$PytMol_Bit_score)[num.bad.baits$AllMis_Bit_score])
num.bad.baits$CheMyd_Matches <- as.character(num.bad.baits$CheMyd_Matches)
num.bad.baits$PelSin_Matches <- as.character(num.bad.baits$PelSin_Matches)
num.bad.baits$AllMis_Matches <- as.character(num.bad.baits$AllMis_Matches)
num.bad.baits$PytMol_Matches <- as.character(num.bad.baits$PytMol_Matches)


# if a Bit_scores < 108, then change the Matches value to "NoMatch"
num.bad.baits$CheMyd_Matches[num.bad.baits$CheMyd_Bit_score < 108] <- "NoMatch"
num.bad.baits$PelSin_Matches[num.bad.baits$PelSin_Bit_score < 108] <- "NoMatch"
num.bad.baits$AllMis_Matches[num.bad.baits$AllMis_Bit_score < 108] <- "NoMatch"
num.bad.baits$PytMol_Matches[num.bad.baits$PytMol_Bit_score < 108] <- "NoMatch"


# add new column to count the number of "bad" baits
num.bad.baits$Sum_NoMatch_All_Genomes = c(apply(num.bad.baits, 1, function(x) sum(x == 'NoMatch', na.rm=TRUE)))


# output the baits (i.e., rows) that have no matches in any genome (i.e., Sum_NoMatch_All_Genomes == 4)
num.bad.baits.all <- (num.bad.baits[num.bad.baits$Sum_NoMatch_All_Genomes == 4, ])
bad.baits <- paste ("The number of baits that did not work in any of
                    the four genomes (i.e., non-working baits) is ",
                    nrow(num.bad.baits.all), sep="")
print(bad.baits)

#write the output
write.table(num.bad.baits.all,
              file= "baits_not_working_in_any_genome.txt",
              append = FALSE, quote = FALSE, sep = "\t",
              eol = "\n", na = "NA", dec = ".", row.names = FALSE,
              col.names = FALSE)
  

# calculates the total number of baits
totalbaits <- nrow(AllMis)

# Perbaits_GopPol from ZERO_CVG_TARGETS_PCT metric determined
# by Picardtools CalculateHsMetrics
Perbaits_GopPol <- 100-(0.046151*100)

# Calculates the percentage of working baits by counting rows,
# dividing by totalbaits, and multiplying by 100
Perbaits_CheMyd <- (nrow(workbaits_CheMyd)/totalbaits)*100
Perbaits_PelSin <- (nrow(workbaits_PelSin)/totalbaits)*100
Perbaits_AllMis <- (nrow(workbaits_AllMis)/totalbaits)*100
Perbaits_PytMol <- (nrow(workbaits_PytMol)/totalbaits)*100

# create the vector Perbaits
Perbaits <- c(Perbaits_GopPol, Perbaits_CheMyd, Perbaits_PelSin, 
              Perbaits_AllMis, Perbaits_PytMol)

# Calcuate intercept and slope of best fit line for all points
# except Gopher tortoise
coefficient <- coef(lm(Perbaits[2-5]~Age[2-5]))

# Combine all 3 variables into a data.frame
SpeciesAgePerbaits <- data.frame(v1=Species, v2=Age, v3=Perbaits)

# use ggplot to graph the relationship between Age and Perbaits
# geome_abline plots the best fit line


p <-ggplot(SpeciesAgePerbaits, aes(Age,Perbaits)) + 
  theme_bw() + 
  theme(panel.border = element_rect(linetype = "solid", colour = "black"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
  geom_abline(intercept = coefficient[1], slope = coefficient[2]) +
  geom_point(size = 4) + 
  geom_text(label=SpeciesAgePerbaits$v1, fontface=3, hjust=1.1) +
  xlab(expression(paste("Approx. age (mya) of most recent common ancestor to "
                        ,italic("C. p. bellii")))) + 
  ylab("Percentage of working baits") +
  theme(axis.text = element_text(size = rel(1.2))) + 
  theme(axis.title = element_text(size = rel(1.4), vjust=-0.1))

# tells ggplot to make x from (0,300) and y from (0,100)
p <- p + expand_limits(x = 300, y = 100) + expand_limits(x = 0, y = 0)

# tells ggplot to expand values
p + scale_x_continuous(expand = c(0, 0),
                       minor_breaks = seq(0 , 300, 10),
                       breaks = seq(0, 300, 50)) + 
  scale_y_continuous(expand = c(0, 0),
                     minor_breaks = seq(0 , 100, 10),
                     breaks = seq(0, 100, 20))

# saves plot as Figure2.pdf in current working directory
ggsave("Figure2.pdf")
ggsave("Figure2.png")

# Calculate Pearson correlation coefficient
# do not include GopPol data

cor.test(Age[2-5],Perbaits[2-5], method='pearson', 
         exact=TRUE, alternative= "less")
# data:  Age[2 - 5] and Perbaits[2 - 5]
# t = -78.0674, df = 2, p-value = 8.202e-05
# alternative hypothesis: true correlation is less than 0
# 95 percent confidence interval:
#   -1.0000000 -0.9956073
# sample estimates:
#   cor 
# -0.999836 