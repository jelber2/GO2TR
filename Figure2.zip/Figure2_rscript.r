######################################################################
# R script for calculating and graphing values in Figure 2 in:
# 
# Elbers JP, Taylor SS (in review) GO2TR: a gene ontology-based
# workflow to generate target regions for target enrichment
# experiments. Molecular Ecology Resources.
#
# Jean P. Elbers
# jean.elbers@gmail.com
# last modified: 1 Dec 2014
######################################################################

#set cwd to where ever you have you bait results
setwd("bait_blat_results")

#load ggplot or get it from CRAN
library("ggplot2", lib.loc="/Library/Frameworks/R.framework/Versions/3.1/Resources/library")

## Species
# GopPol = Gopherus polyphemus, gopher tortoise
# CheMyd = Chelonia mydas, green sea turtle
# PelSin = Pelodiscus sinensis, Chinese softshell
# AllMis = Alligator mississippiensis, American alligator
# PytMol = Python molorus, Burmese python
Species <- c("Gopher tortoise", "Green sea turtle",
             "Chinese soft-shelled turtle", "American alligator",
             "Burmese python")

## Age (Ma) of most recent common ancestor to western painted turtle
# Ma = millions of years ago
# Age[1], Age[2], Age[3] from age estimates of nodes 22, 18, and 2
# respectively from Table 2 in: 
# Near TJ, Meylan PA and Shaffer HB (2005) Assessing Concordance of
# Fossil Calibration Points in Molecular Clock Studies: An Example
# Using Turtles. The American Naturalist 165: 137-146.
# Age[4] and Age[5] from age estimates of nodes 4 and 2 respectively
# from Table 1 in:
# Shedlock AM and Edwards SV (2009) Amniotes (amniota). In:
# S. B. Hedges and S. Kumar, editors. The timetree of life.
# Oxford. pp. 375-379.
# create the vector Age
Age <- c(69.98, 93.68, 174.87, 230.7, 274.9) 

## Percent of Working Baits
# import tab-delimited BLAT search results for each genome
# to create the following data.frames
CheMyd <-read.delim("bait_matches_4col_reformat_CheMyd.txt", header=F)
PelSin <-read.delim("bait_matches_4col_reformat_PelSin.txt", header=F)
AllMis <-read.delim("bait_matches_4col_reformat_AllMis.txt", header=F)
PytMol <-read.delim("bait_matches_4col_reformat_PytMol.txt", header=F)

# A bait "worked" if it had a bit score > 108 (~10% divergence 
# aka 90% similarity = 120*0.9)
# so only count the rows that have bit scores >= 108
# by filtering the existing data.frames
workbaits_CheMyd <- na.omit(CheMyd[CheMyd$V4 >= 108, ])
workbaits_PelSin <- na.omit(PelSin[PelSin$V4 >= 108, ])
workbaits_AllMis <- na.omit(AllMis[AllMis$V4 >= 108, ])
workbaits_PytMol <- na.omit(PytMol[PytMol$V4 >= 108, ])

# calculates the total number of baits
totalbaits <- nrow(AllMis)

# Perbaits_GopPol from ZERO_CVG_TARGETS_PCT metric determined
# by Picardtools CalculateHsMetrics
Perbaits_GopPol <- 100-(0.046151*100)

# Calculates the percentage of working baits by counting rows,
# dividing by totalbaits, and multiplying by 100
Perbaits_CheMyd <- (nrow(workbaits_CheMyd)/totalbaits)*100
Perbaits_PelSin <- (nrow(workbaits_PelSin)/totalbaits)*100
Perbaits_AllMis <- (nrow(workbaits_AllMis)/totalbaits)*100
Perbaits_PytMol <- (nrow(workbaits_PytMol)/totalbaits)*100

# create the vector Perbaits
Perbaits <- c(Perbaits_GopPol, Perbaits_CheMyd, Perbaits_PelSin, 
              Perbaits_AllMis, Perbaits_PytMol)

# Calcuate intercept and slope of best fit line for all points
# except Gopher tortoise
coefficient <- coef(lm(Perbaits[2-5]~Age[2-5]))

# Combine all 3 variables into a data.frame
SpeciesAgePerbaits <- data.frame(v1=Species, v2=Age, v3=Perbaits)

# use ggplot to graph the relationship between Age and Perbaits
# geome_abline plots the best fit line
p <-ggplot(SpeciesAgePerbaits, aes(Age,Perbaits)) + theme_bw() + theme(panel.border = element_rect(linetype = "solid", colour = "black"), panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +  geom_abline(intercept = coefficient[1], slope = coefficient[2]) + geom_point(size = 4) + xlab("Approx. age (mya) of most recent common ancestor to western painted turtle") + ylab("Percentage of working baits") + theme(axis.text = element_text(size = rel(1.2))) + theme(axis.title = element_text(size = rel(1.4)))

# tells ggplot to start that max x =300, y=100
p <- p + expand_limits(x = 300, y = 100)
# tells ggplot that min x=0, y=0
p <- p + expand_limits(x = 0, y = 0)

# tells ggplot to expand values
p + scale_x_continuous(expand = c(0, 0), minor_breaks = seq(0 , 300, 10), breaks = seq(0, 300, 50)) + scale_y_continuous(expand = c(0, 0), minor_breaks = seq(0 , 100, 10), breaks = seq(0, 100, 20))

# saves plot as Figure2.pdf in current working directory
ggsave("Figure2.pdf")


# Calculate Pearson correlation coefficient
# do not include GopPol data
cor(Age[2-5],Perbaits[2-5], method='pearson')
# [1] -0.999836