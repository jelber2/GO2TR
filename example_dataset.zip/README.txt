To create the dog immunome, I used default GO2TR settings
(see https://github.com/jelber2/GO2TR/blob/master/README.md).

User-specified gff3 file and GO term information:

    gff3 file used:
        ftp://ftp.ncbi.nlm.nih.gov/genomes/Canis_lupus_familiaris/GFF/ref_CanFam3.1_top_level.gff3.gz

    GO term (GO:id) used:
        immune response (GO:0006955)

Jean Elbers
jelber2@lsu.edu
10 November 2014
